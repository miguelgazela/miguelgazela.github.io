var timelineMonthTemplate = '<% for (var i = 0; i < numberOfDays; i++) { %>' +
		'<li class="<%= days[i].classes %>" data-timeline-day-date="<%= days[i].date.format(\"DD-MM-YYYY\") %>"><span class="timeline-month-day-digits"><%= days[i].day %></span><span class="timeline-month-day-weekday"><%= days[i].date.format(\"dddd\") %></span></li>' +
	'<% } %>';

var filteredDates 				= [],
	previouslySelectedDays 		= [],
	previousSearchQuery			= "",
	firstTimelineDaySelected 	= null,
	lastTimelineDaySelected 	= null,
	selectionIntervalStart 		= null,
	selectionIntervalEnd 		= null,
	t0 							= null
	t1 							= null;
	mouseIsDown 				= false,
	cmdIsPressed 				= false,
	shiftIsPressed 				= false,
	compiledTimelineTemplate 	= null,
	logging 					= true,
	scrollSpyIsActive 			= true,
	focusCounter				= 0,
	eventDates 					= ['2015-11-04 10:22:11 +0000', '2015-11-03 10:22:11 +0000', '2012-03-04 10:22:11 +0000'];

window.addEventListener("keydown", function(e) {

    // space and arrow keys
    if([32, 37, 38, 39, 40].indexOf(e.keyCode) > -1) {
        e.preventDefault();
    }
}, false);

$(window).scroll(function(){

	var $w 				= $(window),
		viewTop 		= $w.scrollTop();

	if (scrollSpyIsActive) {

		$('.timeline-month').each(function() {

			var $month = $(this);

			var offset = $month.offset(),
				height = $month.height(),
				_top   = offset.top;

			if (_top < viewTop && (_top + height) >= viewTop) {

				$('.navbar-year').removeClass('active');
				$('.navbar-year li').removeClass('active');

				var date = moment($month.data('timeline-date'), 'MM-YYYY');

				var year = $(".navbar-year[data-year='" + date.format('YYYY') + "']");
				var month = $(year).find("li[data-date='" + date.format('MM-YYYY') + "']");

				year.addClass('active');
				year.removeClass("collapsed");

				month.addClass('active');

				var $navbar			= $("#timeline-navbar"),
					navbarHeight 	= $navbar.height(),
					navbarTop 		= $navbar.scrollTop(),
					navbarBottom 	= navbarTop + navbarHeight,
					offsetTop 		= month.position().top,
					height 			= month.height();

				// if it is not visible in the navbar

				if (offsetTop < 0) {

					$('#timeline-navbar').animate({
				        scrollTop: navbarTop - 30
				    }, 0);

					// $("#state").html("not visible");

				} else if ((offsetTop + height + navbarTop) > navbarBottom) {

					$('#timeline-navbar').animate({
				        scrollTop: navbarTop + 30
				    }, 0);

				}

				return false;
			}
		});
	}
});

$(document).ready(function () {

	compiledTimelineTemplate = _.template(timelineMonthTemplate);

	$(this)
		.off()
		.mouseup(function () {

			mouseIsDown = false;
	});

	// addCurrentMonth();
	// refreshContents();
	// search('today from 16:00 to 17:00');
	// bindEvents();
});

function gainedFocus() {

	focusCounter += 1;
	$(document.body).removeClass('no-focus');
}

function lostFocus() {

	focusCounter = 0;
	$(document.body).addClass("no-focus");
}

function commandKeyPressed(isPressed) {

	cmdIsPressed = isPressed;
}

function shiftKeyPressed(isPressed) {

	shiftIsPressed = isPressed;
}

/*****************************************************************************
* MONTHS METHODS
******************************************************************************
*/

function addTimelineToMonth(month) {

	var intervalStart = month.clone();
	var intervalEnd = month.clone().endOf('month');

	var timelineMonthContainer = $(".timeline-month[data-timeline-date='" + month.format('MM-YYYY') + "']");

	if (timelineMonthContainer.length != 0) {

		var $container = $(timelineMonthContainer[0]);

		if ($container.children('li').length == 0) {

			var days = createTimelineMonthDaysObject(intervalStart, intervalEnd),
			data = {
				days: days.reverse(),
				month: month.format('MMMM'),
				numberOfDays: days.length
			};

			$(timelineMonthContainer[0]).append(compiledTimelineTemplate(data));
		
		} else {
			$container.children('li').removeClass('hidden');
		}
	}
}

/*****************************************************************************
* CREATION METHODS
******************************************************************************
*/

function createTimeline() {

	// timeMe();

	$('#timeline-navbar').html("");
	$('#timeline').html("");

	var oldestDate = null,
		newestDate = null;

	$.each(eventDates, function() {

		var eventDateMonth = getEventDateMoment(this).startOf('month');

		if (oldestDate == null && newestDate == null) {

			oldestDate = eventDateMonth.clone();
			newestDate = eventDateMonth.clone();
		}

		if (eventDateMonth.isBefore(oldestDate) && eventDateMonth.year() != 1970) {
			oldestDate = eventDateMonth.clone();
		}

		if (eventDateMonth.isAfter(newestDate)) {
			newestDate = eventDateMonth.clone();
		}
	});

	// create the months between the oldest and the most recent date

	if (oldestDate != null && newestDate != null) {

		var dateIterator = newestDate.clone();

		while (dateIterator.isAfter(oldestDate) || dateIterator.isSame(oldestDate, 'day')) {

			// check if month already exists

			var timelineMonth = $(".timeline-month[data-timeline-date='" + dateIterator.format('MM-YYYY') + "']");

			if (timelineMonth.length == 0) {

				var timelineMonthContainer = $('<ul class="timeline-month" data-timeline-date="' + dateIterator.format('MM-YYYY') + '"><p class="timeline-month-title">'+ dateIterator.format('MMMM') +'</p></ul>');
				$("#timeline").append(timelineMonthContainer);
			}

			// add navbar timeline

			var navbarYear = $(".navbar-year[data-year='" + dateIterator.format('YYYY') + "']");

			if (navbarYear.length == 0) {

				var yearContainer = $('<div class="navbar-year" data-year="' + dateIterator.format('YYYY') + '"><p class="navbar-title">' + dateIterator.format('YYYY') + '</p><ul><li data-date="' + dateIterator.format('MM-YYYY') +'">' + dateIterator.format('MMM') + '</li></ul></div>');
				$("#timeline-navbar").append(yearContainer);
			}

			var $month = $(".navbar-year li[data-date='" + dateIterator.format('MM-YYYY') + "']");

			if ($month.length == 0) {
				$(navbarYear[0]).children('ul').append('<li data-date="' + dateIterator.format('MM-YYYY') +'">' + dateIterator.format('MMM') + '</li>');
			}

			dateIterator.subtract(1, 'month');
		};

		$('.navbar-year').addClass('collapsed');
		$('.navbar-year:first-of-type').removeClass("collapsed");

		$('.navbar-year:first-of-type').addClass("active");
		$('.navbar-year:first-of-type').find('li:first-of-type').addClass("active");

		// add days to the months that have messages

		$.each(eventDates, function() {

			var eventDateMonth = getEventDateMoment(this).startOf('month');
			addTimelineToMonth(eventDateMonth);

			var day = $($(".timeline-month-day[data-timeline-day-date='" + getEventDateMoment(this).format('DD-MM-YYYY') + "']")[0]);

			if (day != undefined) {
				day.addClass('has-messages');
			}
		});

	} else {

		$("#timeline").append("No dates available.");
	}

	

	// done("Created timeline in ");
}

function createTimelineMonthDaysObject(startDate, endDate) {

	var daysArray = [];

	var dateIterator = startDate.clone();

	while ( dateIterator.isBefore(endDate) || dateIterator.isSame(endDate, 'day')) {

		var dayObject = createTimelineDayObject(dateIterator.clone());
		daysArray.push(dayObject);

		if (dayObject.properties.isToday) {
			break;
		}

		dateIterator.add(1, 'days');
	};

	return daysArray;
}

function createTimelineDayObject(day) {

	var now = moment();

	// validate moment date
    if (!day.isValid() && day.hasOwnProperty('_d') && day._d != undefined) {
        day = moment(day._d);
    }

    var properties = {
      isToday: false,
      isWeekend: false
    };

    var extraClasses = "";

    if(now.format("YYYY-MM-DD") == day.format("YYYY-MM-DD")) {

      extraClasses += (" timeline-month-day-today");
      properties.isToday = true;
    }

    if (day.weekday() == 0 || day.weekday() == 6) {
    	extraClasses += " timeline-month-day-weekend";
    	properties.isWeekend = true;
    }

    return dayObject({
    	day: day.format('DD'),
    	classes: "timeline-month-day" + extraClasses,
    	date: day,
    	properties: properties
    });
}

function dayObject(options) {

	var defaults = { day: "", classes: null, date: null};
	return $.extend({}, defaults, options);
}

function refreshContents(query) {

	createTimeline();

	var oldSelectedDays = previouslySelectedDays.slice();

	clearSelection();

	if (eventDates.length == 0) {

		filterMessages();
		return;
	}

	if (query !== "") {

		if (query) {

			previousSearchQuery = query;

			// search returns true if it did the filtering by itself

			if(!search(query)) {

				bindEvents();
				filterMessages();
			}
		}

	} else {

		// the search query was cleared

		if (previousSearchQuery !== "") {

			previousSearchQuery = query;

			clearSelection();

			bindEvents();
			filterMessages();

			return;
		}

		// if it had days selected before rebuilding the timeline

		if (oldSelectedDays.length != 0) {

			$.each(oldSelectedDays, function(index) {

				// check if it is still displayed

				var date = moment(this.data('timeline-day-date'), 'DD-MM-YYYY');
				var targetDay = $(".timeline-month-day[data-timeline-day-date='" + date.format('DD-MM-YYYY') + "']");

				if (targetDay.length != 0) {
					selectSingleDay(targetDay);

					if (index != (oldSelectedDays.length - 1)) {
						targetDay.removeClass("timeline-month-day-last-selected");
					}
				}
			});
		}

		bindEvents();
		filterMessages();
	}
}

function filterMessages() {

	viewController.filterMessagesWithDates_(JSON.stringify(filteredDates));
}

function search(query) {

	var results = chrono.parse(query);

	if (results.length != 0) {

		if (!results[0].end) {

			var date = results[0].start.knownValues;
			var targetDayDate;

			// single day

			if (date.weekday) {

				date = results[0].start.impliedValues;
				targetDayDate = moment("" + date.day + "-" + date.month + "-" + date.year, 'DD-MM-YYYY');

			} else {
				targetDayDate = moment("" + date.day + "-" + date.month + "-" + date.year, 'DD-MM-YYYY');
			}

			var targetDay = $(".timeline-month-day[data-timeline-day-date='" + targetDayDate.format('DD-MM-YYYY') + "']");

			if (targetDay.length != 0) {
				selectSingleDay(targetDay);
			}

		} else {
			
			var startDate = results[0].start.knownValues;
			var endDate = results[0].end.knownValues;

			if (startDate.hour && endDate.hour) {
				
				startDate = moment("" + startDate.day + "-" + startDate.month + "-" + startDate.year + " " + startDate.hour + ":" + startDate.minute, 'DD-MM-YYYY HH:mm');
				endDate = moment("" + endDate.day + "-" + endDate.month + "-" + endDate.year + " " + endDate.hour + ":" + endDate.minute, 'DD-MM-YYYY HH:mm');

				// selects one day

				var targetDay = $(".timeline-month-day[data-timeline-day-date='" + startDate.format('DD-MM-YYYY') + "']");

				if (targetDay.length != 0) {
					selectSingleDay(targetDay);
				}

			} else {
				
				startDate = moment("" + startDate.day + "-" + startDate.month + "-" + startDate.year, 'DD-MM-YYYY').startOf('day');
				endDate = moment("" + endDate.day + "-" + endDate.month + "-" + endDate.year, 'DD-MM-YYYY').endOf('day');

				// selects several days

				$(".timeline-month-day").each(function () {

					var dayDate = getDayDate($(this));

					if (dayDate.isAfter(startDate) && dayDate.isBefore(endDate)) {
						selectSingleDay($(this));
					}

					if (dayDate.isSame(startDate)) {
						selectSingleDay($(this));
					}

					if (dayDate.isSame(endDate)) {
						selectSingleDay($(this));
					}
				});
			}

			previouslySelectedDays.length = 0;
			filteredDates.length = 0;

			filteredDates.push(startDate.format('DD-MM-YYYY HH:mm:ss'));
			filteredDates.push(endDate.format('DD-MM-YYYY HH:mm:ss'));

			viewController.filterMessagesBetweenDates_(JSON.stringify(filteredDates));

			return true;
		}
	}

	return false;
}

function bindEvents() {

	bindTimelineDayEvents();

	$('.navbar-year li')
		.off()
		.click(function() {

			var date = moment($(this).data('date'), 'MM-YYYY');
			var month = $(".timeline-month[data-timeline-date='" + date.format('MM-YYYY') + "']");

			scrollSpyIsActive = false;

			$('html, body').stop().animate({
				scrollTop: $(month).offset().top - 10
			}, 300, function() {

				scrollSpyIsActive = true;
			});

			// TODO: needs to check if it changed the year

			$('.navbar-year li').removeClass('active');
			$(this).addClass("active");
		});

	$('.navbar-title')
		.off()
		.click(function () {

			var $month = $(this).parent();
			$month.toggleClass('collapsed');

		});

	$('.timeline-month-title')
		.off()
		.click(function () {

			var $title = $(this);

			if (!$title.hasClass("selected")) {

				clearSelection();
				// if (!cmdIsPressed) {
				// 	clearSelection();
				// }

				$title.addClass("selected");

				// if month has no dates inside

				if ($title.siblings().length == 0) {

					var singleEmptyDate = moment($title.parent('ul').data('timeline-date'), 'MM-YYYY');
					filteredDates.push(singleEmptyDate.format('DD-MM-YYYY'));
				}

				$.each($title.siblings(), function () {

					var date = $(this).data('timeline-day-date');

					$(this).addClass('timeline-month-day-selected');

					previouslySelectedDays.push($(this));	
					filteredDates.push(date);
				});

			} else {
				clearSelection();
			}

			filterMessages();
		});
}

function bindTimelineDayEvents() {

	$(".timeline-month-day")
		.off() // removes all handlers attached to this object
		.mousedown(function () {

			mouseIsDown = true;
			firstTimelineDaySelected = $(this);

			return false;

		})
		.mouseover(function () {

		})
		.mouseup(function () {

			if (focusCounter <= 1) {
				// log("HERE!!");
			}

			mouseIsDown = false;

			var timelineDay = $(this);
			var hadMultipleSelection = (previouslySelectedDays.length > 1);
			var previousSelectedTimelineDay = previouslySelectedDays[0];
			var numPreviouslySelectedDays = numSelectedDays();

			if (firstTimelineDaySelected.is(timelineDay)) {

				if (!shiftIsPressed) {

					if (!cmdIsPressed) {
						clearSelection();
					}

					if (numPreviouslySelectedDays == 0) {

						selectSingleDay(timelineDay);
						timelineDay.addClass('timeline-month-day-last-selected');

					} else if (numPreviouslySelectedDays == 1) {

						if (timelineDay.is(previousSelectedTimelineDay)) {
							clearSelection();
						} else {

							selectSingleDay(timelineDay);
							timelineDay.addClass('timeline-month-day-last-selected');
						}

					} else {

						if (timelineDay.hasClass("timeline-month-day-selected")) {

							clearDaySelection(timelineDay);
							removeDateFromFilteredDates(timelineDay.data('timeline-day-date'));

						} else {

							selectSingleDay(timelineDay);
							timelineDay.addClass('timeline-month-day-last-selected');
						}
					}

					// if (!previousSelectedTimelineDay || !previousSelectedTimelineDay.is(timelineDay) || hadMultipleSelection) {

					// 	selectSingleDay(timelineDay);
					// 	timelineDay.addClass('timeline-month-day-last-selected');
					// }

				} else {

					if (numPreviouslySelectedDays == 0) {

						$(".timeline-month-day").each(function () {
							
							selectSingleDay($(this));
							$(this).removeClass('timeline-month-day-last-selected');
							
							if ($(this).is(timelineDay)) {

								$(this).addClass('timeline-month-day-last-selected');
								return false;
							}
						});

					} else if (numPreviouslySelectedDays == 1) {

						var targetDate = moment($(this).data('timeline-day-date'), 'DD-MM-YYYY');
						var previouslySelectedDate = moment(previousSelectedTimelineDay.data('timeline-day-date'), 'DD-MM-YYYY');

						var startDay, endDay;

						if (previouslySelectedDate.isBefore(targetDate)) {

							startDay = $(this);
							endDay = previousSelectedTimelineDay;

						} else {

							startDay = previousSelectedTimelineDay;
							endDay = $(this);
						}

						var selecting = false;

						$(".timeline-month-day").each(function () {

							if (!selecting && $(this).is(startDay)) {
								selecting = true;
							}

							if (selecting) {
								selectSingleDay($(this));
								$(this).removeClass('timeline-month-day-last-selected');
							}
							
							if ($(this).is(endDay)) {

								$(this).addClass('timeline-month-day-last-selected');
								return false;
							}
						});

					} else {

						var continuousSelection = isSelectionContinuous(numPreviouslySelectedDays);

						var lastSelectedDay = previouslySelectedDays[numSelectedDays() - 1];
						var lastSelectedDate = moment(lastSelectedDay.data('timeline-day-date'), 'DD-MM-YYYY');
						var targetDate = moment($(this).data('timeline-day-date'), 'DD-MM-YYYY');

						var startDay, endDay;

						if (lastSelectedDate.isBefore(targetDate)) {

							startDay = $(this);
							endDay = lastSelectedDay;

						} else {

							startDay = lastSelectedDay;
							endDay = $(this);
						}

						if (continuousSelection) {
							clearSelection();
						}

						var selecting = false;

						$(".timeline-month-day").each(function () {

							if (!selecting && $(this).is(startDay)) {
								selecting = true;
							}

							if (selecting) {
								selectSingleDay($(this));
								$(this).removeClass('timeline-month-day-last-selected');
							}
							
							if ($(this).is(endDay)) {

								$(this).addClass('timeline-month-day-last-selected');
								return false;
							}
						});

					}
				}
			}

			filterMessages();
		});
}

/*****************************************************************************
* SELECTION METHODS
******************************************************************************
*/

function clearSelection() {

	$('.timeline-month-title').removeClass("selected");

	$.each(previouslySelectedDays, function () {
		clearDaySelection($(this));
	});

	previouslySelectedDays.length = 0;
	filteredDates.length = 0;
}

function clearDaySelection(day) {

	day.removeClass("timeline-month-day-selected");
	day.removeClass("timeline-month-day-last-selected")
}

// the before is in time, not interface

function findDayBefore($day) {

	// var date 			= moment($day.data('timeline-day-date'), 'DD-MM-YYYY'),
	// 	targetDayDate 	= date.clone().subtract(1, 'day'),
	// 	targetDay 			= $(".timeline-month-day[data-timeline-day-date='" + targetDayDate.format('DD-MM-YYYY') + "']");

	// if (targetDay.length != 0) {
	// 	return {day: $(targetDay[0])};
	// } else {
	// 	return {day: null, isSameMonth: true, isSameYear: true};
	// }

	var properties = {
		isSameMonth: true
	};

	// check if it is the last day of the current month

	if ($day.is(":last-child")) {

		var $month = $day.parent('.timeline-month');

		properties.isSameMonth = false;

		if ($month.is(":last-child")) {
			return {day: null, properties: properties};
		} else {

			while (true) {

				var $nextMonth = $month.next('.timeline-month');

				// if month has days in it

				if ($nextMonth.find('li').length != 0) {

					// choose the first day
					var $nextDay = $nextMonth.find('li:first-of-type');
					return {day: $nextDay, properties: properties};

				} else {

					// advance to the next month
					if ($nextMonth.is(":last-child")) {
						return {day: null, properties: properties};
					} else {

						$month = $nextMonth;
					}
				}
			}

			return {day: null, properties: properties};
		}

	} else {

		// it has a sibling, so return it
		return {day: $day.next('.timeline-month-day'), properties: properties};
	}
}

function findDayAfter($day) {

	var properties = {
		isSameMonth: true
	};

	// check if it is the first day of the current month

	if ($day.is(":first-of-type")) {

		properties.isSameMonth = false;

		var $month = $day.parent('.timeline-month');

		if ($month.is(":first-of-type")) {
			return {day: null, properties: properties};
		} else {

			while (true) {

				var $prevMonth = $month.prev('.timeline-month');

				// if month has days in it

				if ($prevMonth.find('li').length != 0) {

					// choose the last day
					var $prevDay = $prevMonth.find('li:last-of-type');
					return {day: $prevDay, properties: properties};

				} else {

					// advance to the next month
					if ($prevMonth.is(":first-of-type")) {
						return {day: null, properties: properties};
					} else {

						$month = $prevMonth;
					}
				}
			}

			return {day: null, properties: properties};
		}

	} else {

		// it has a sibling, so return it
		return {day: $day.prev('.timeline-month-day'), properties: properties};
	}
}

function selectSingleDay(day) {

	selectDay(day, "timeline-month-day-selected timeline-month-day-last-selected");
}

function selectDay(day, classes) {

	day.addClass(classes);

	var date = day.data('timeline-day-date');

	previouslySelectedDays.push(day);
	filteredDates.push(date);

	if (!isVisible(day)) {

		var $w 				= $(window),
			viewportHeight 	= $w.height(),
			viewTop			= $w.scrollTop(),
			viewBottom 		= viewTop + viewportHeight,
			offset 			= day.offset(),
			height 			= day.height(),
			_top 			= offset.top;

		if ((_top + height) <= viewTop || (_top <= viewTop && (_top + height) > viewTop)) {

			// it's above the viewport

			$('html, body').animate({
				scrollTop: _top - 20
			}, 0);

		} else if (_top >= viewBottom || (_top < viewBottom && (_top + height) > viewBottom)) {

			// it's below the viewport

			$('html, body').animate({
				scrollTop: viewTop + (_top - viewBottom) + height + 20
			}, 0);
		}
	}
}

function hasSelection() {

	return numSelectedDays() != 0;
}

function numSelectedDays() {

	return previouslySelectedDays.length;
}

function selectNewestDay() {

	var $firstDay = $($('.timeline-month-day')[0]);
	selectSingleDay($firstDay);
}

function isSelectionContinuous(numDaysSelected) {

	var foundFirstSelected = false;
	var counter = 0;

	$(".timeline-month-day").each(function () {

		var dayIsSelected = $(this).hasClass("timeline-month-day-selected");
		
		if (!foundFirstSelected && dayIsSelected) {
			foundFirstSelected = true;
		}

		if (foundFirstSelected) {

			if (dayIsSelected) {
				counter += 1;
			} else {

				return false; // ending each loop
			}
		}
	});

	return counter == numDaysSelected;
}

/*****************************************************************************
* ARROW SELECTION
******************************************************************************
*/

function acceptSelection() {

	// change this to the most recent

	if (!hasSelection()) {

		selectNewestDay();
		filterMessages();
	}
}

function upArrowPressed() {

	if (!hasSelection()) {

		selectNewestDay();
		filterMessages();

		return;
	}

	if (shiftFlag && previouslySelectedDays.length != 0) {

		var lastDaySelected = previouslySelectedDays[numSelectedDays() - 1],
			result 			= findDayAfter(lastDaySelected);

		if (result.day != null) {

			if (result.day.hasClass("timeline-month-day-selected")) {

				clearDaySelection(lastDaySelected);
				removeDateFromFilteredDates(getDayDate(lastDaySelected).format('DD-MM-YYYY'));
				previouslySelectedDays.pop();

			} else {
				selectSingleDay(result.day);
				result.day.removeClass("timeline-month-day-last-selected");
			}

			
			filterMessages();
		}

		return;
	}

	var result = findDayAfter(previouslySelectedDays[numSelectedDays() - 1]);

	if (numSelectedDays() > 1) {

		if (result.day == null) {

			// select the last one of the already selected
			var lastDay = previouslySelectedDays[numSelectedDays() - 1];

			clearSelection();
			selectSingleDay(lastDay);

			filterMessages();
			return;
		}
	}

	if (result.day != null) {

		clearSelection();
		selectSingleDay(result.day);

		filterMessages();
	}
}

function downArrowPressed() {

	if (!hasSelection()) {

		selectNewestDay();
		filterMessages();

		return;
	}

	if (shiftFlag && previouslySelectedDays.length != 0) {

		var lastDaySelected = previouslySelectedDays[numSelectedDays() - 1],
			result 			= findDayBefore(lastDaySelected);

		if (result.day != null) {

			if (result.day.hasClass("timeline-month-day-selected")) {

				clearDaySelection(lastDaySelected);
				removeDateFromFilteredDates(getDayDate(lastDaySelected).format('DD-MM-YYYY'));
				previouslySelectedDays.pop();

			} else {
				lastDaySelected.removeClass("timeline-month-day-last-selected");
				selectSingleDay(result.day);
			}

			filterMessages();
		}

		return;
	}

	var result = findDayBefore(previouslySelectedDays[numSelectedDays() - 1]);

	if (numSelectedDays() > 1) {

		if (result.day == null) {

			// select the last one of the already selected
			var lastDay = previouslySelectedDays[numSelectedDays() - 1];

			clearSelection();
			selectSingleDay(lastDay);

			filterMessages();
			return;
		}
	}

	if (result.day != null) {

		clearSelection();
		selectSingleDay(result.day);

		filterMessages();
	}
}

/*****************************************************************************
* UTILITY METHODS
******************************************************************************
*/

function isVisible(elem) {

	var $w 				= $(window),
		viewportHeight 	= $w.height(),
		viewTop 		= $w.scrollTop(),
		viewBottom 		= viewTop + viewportHeight,
		offset 			= elem.offset(),
		height 			= elem.height(),
		_top			= offset.top;

	return (_top >= viewTop) && ((_top + height) <= viewBottom);
}

function scrollTo(elem) {

	$('html, body').animate({
        scrollTop: elem.offset().top - 80
    }, 'fast');
}

function scrollToDay(day) {

	if(!isVisible(day)) {
		scrollTo(day);
	}
}

function sameDay(date1, date2) {

	return (date1.dayOfYear() == date2.dayOfYear() && date1.year() == date2.year());
}

function getDayDate(day) {

	return moment(day.data('timeline-day-date'), 'DD-MM-YYYY');
}

function getEventDateMoment(eventDate) {

	return moment(eventDate, 'YYYY-MM-DD HH:mm:ss +SSSS');
}

function removeDateFromFilteredDates(date) {

	var index = _.indexOf(filteredDates, date);

	if (index != -1) {
		filteredDates.splice(index, 1);
	}	
}

function log(value) {

	viewController.consoleLog_(value);
}

function timeMe() {
	t0 = performance.now();
}

function done(message) {

	t1 = performance.now();

	if (logging) {
		console.log(message + " took: " + (t1 - t0) + " milliseconds");
		viewController.consoleLog_(message + " took: " + (t1 - t0) + " milliseconds");
	}

	t0 = null;
	t1 = null;
}